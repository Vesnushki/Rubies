<?php

use Irs\BehatPopupExtension\PopupContext,
    Irs\BehatUimapExtension\Context\UimapContext,
    Irs\BehatUimapExtension\PageSource\TafSource,
    Irs\BehatMagentoExtension\Context\MagentoHooks;

use Behat\Behat\Context\ClosuredContextInterface,
    Behat\Behat\Context\TranslatedContextInterface,
    Behat\Behat\Context\BehatContext,
    Behat\Behat\Exception\PendingException,
    Behat\Gherkin\Node\PyStringNode,
    Behat\Gherkin\Node\TableNode,
    Behat\MinkExtension\Context\MinkAwareInterface;

/**
 * Features context.
 */
class FeatureContext extends BehatContext implements MinkAwareInterface
{
    use /*MagentoHooks,*/ UimapContext, PopupContext;

    /**
     * Initializes context.
     * Every scenario gets it's own context object.
     *
     * @param array $parameters context parameters (set them up through behat.yml)
     */
    public function __construct(array $parameters)
    {
        // Initialize your context here
    }

    /**
     * @Given /^I am logged in to admin panel$/
     */
    public function iAmLoggedInToAdminPanel()
    {
        $this->loadPage('log_in_to_admin');
        $this->visit('log_in_to_admin');
        $this->fillField('user_name', 'admin');
        $this->fillField('password', 'passwd4admin');
        $this->findField('login', 'button', 'log_in')->press();
        $this->assertPageContainsText('Dashboard');
    }

    /**
     * @Then /^I logout from admin panel$/
     */
    public function logoutFromAdminPanel()
    {
        $this->getMink()->assertSession()->elementExists('xpath', "//a[@class = 'link-logout']")->click();
    }

    /**
     * @Then /^I should see \'([^\']*)\' JS alerts$/
     */
    public function iShouldSeeJsAlerts($count)
    {
        $this->getMink()->assertSession()->elementsCount('xpath', "//div[contains(@class, 'validation-advice')]", $count);
    }

    /**
     * Presses button with specified id|name|title|alt|value.
     *
     * @When /^(?:|I )press "(?P<button>(?:[^"]|\\")*)"$/
     */

    public function pressButton($button)
    {
        $button = $this->fixStepArgument($button);
        $this->getSession()->getPage()->pressButton($button);
    }

    /**
     * Presses button with specified id|name|title|alt|value without fieldset specified
     *
     * @When /^(?:|I )press "(?P<button>(?:[^"]|\\")*)" button$/
     */
    public function pressButtonWithoutFieldset($button)
    {
        $this->pressButton($button);
        //workaround for page load
        $this->waitForSeconds(3);
    }

    /**
     * Presses button with specified id|name|title|alt|value.
     *
     * @When /^I press "([^"]*)" in fieldset "([^"]*)"$/
     */
    public function pressButtonInFieldset($button, $fieldset)
    {
        $this->findField($button,'button', $fieldset)->press();

    }

    /**
     * @When /^(?:|I )select "(?P<text>(?:[^"]|\\")*)" from grid$/
     */
    public function selectElementFromGrid($text)
    {
        $this->getMink()->assertSession()->elementExists('xpath', "//td[contains(text(), '$text')]")->click();
    }

    /**
     * @Given /^I am logged in to frontend as "([^"]*)" with password "([^"]*)"$/
     */
    public function iAmLoggedToFrontend($email, $password)
    {
        $this->visit('customer_login');
        $this->currentPage = $this->getPageSource()->getPageByKey('customer_login');
        $this->fillField('email', $email, 'log_in_customer');
        $this->fillField('password', $password, 'log_in_customer');
        $this->findField('login', 'button', 'log_in_customer')->press();
        $this->currentPage = $this->getPageSource()->getPageByKey('customer_account');
    }

    /**
     * @Given /^I log out from frontend$/
     */
    public function logOutFrontend()
    {
        $this->getMink()->assertSession()->elementExists('xpath', "//a[@title = 'Log Out']")->click();
    }

    /**
     * @Given /^I should be on the "(?P<page>[^"]+)"$/
     */
    public function iShouldBeOn($page)
    {
        $this->assertPageAddress($page);
    }

    /**
     * Goes to page and loads proper page by key.
     *
     * @When /^(?:|I )go to "(?P<page>[^"]+)"$/
     */
    public function goToPage($page)
    {   $this->visit($page);
        $this->loadPage($page);
    }

    /**
     * Fills in rating
     *
     * @When /^(?:|I )rate a product$/
     */
    public function setRating()
    {
        $this->clickLink('price_mark', 'customer_reviews');
        $this->loadPage('product_page');
        $this->clickLink('value_mark', 'customer_reviews');
        $this->loadPage('product_page');
        $this->clickLink('quality_mark', 'customer_reviews');
        $this->loadPage('product_page');
    }

    /**
     * Fills in form field with specified id|name|label|value.
     *
     * @When /^(?:|I )fill in "(?P<field>(?:[^"]|\\")*)" with "(?P<value>(?:[^"]|\\")*)" in fieldset "(?P<fieldset>(?:[^"]|\\")*)"$/
     * @When /^(?:|I )fill in "(?P<value>(?:[^"]|\\")*)" for "(?P<field>(?:[^"]|\\")*)" in fieldset "(?P<fieldset>(?:[^"]|\\")*)"$/
     * @When /^(?:|I )fill in "(?P<field>(?:[^"]|\\")*)" with "(?P<value>(?:[^"]|\\")*)" in fieldset "(?P<fieldset>(?:[^"]|\\")*)" of tab "(?P<tab>(?:[^"]|\\")*)"$/
     * @When /^(?:|I )fill in "(?P<value>(?:[^"]|\\")*)" for "(?P<field>(?:[^"]|\\")*)" in fieldset "(?P<fieldset>(?:[^"]|\\")*)" of tab "(?P<tab>(?:[^"]|\\")*)"$/
     * @When /^(?:|I )fill in "(?P<field>(?:[^"]|\\")*)" with "(?P<value>(?:[^"]|\\")*)" in fieldset "(?P<fieldset>(?:[^"]|\\")*)" of tab "(?P<tab>(?:[^"]|\\")*)" with following parameters:$/
     * @When /^(?:|I )fill in "(?P<value>(?:[^"]|\\")*)" for "(?P<field>(?:[^"]|\\")*)" in fieldset "(?P<fieldset>(?:[^"]|\\")*)" of tab "(?P<tab>(?:[^"]|\\")*)" with following parameters:$/
     */
    public function fillField($field, $value, $fieldset = null, $tab = null, TableNode $params = null)
    {
        //use $needle expression in the beginning of the line to randomize the string entered with a-z 0-9 characters
        $needle = '%rand%';
        $randomCharactersAmount = 6;
        $randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $randomCharactersAmount);

        if(stristr($value, $needle))
        {
            $value=substr_replace($value, $randomString, 0,6);;
        }

        $params = ($params) ? $params->getRowsHash() : array();
        $this->findField($field, 'field', $fieldset, $tab, $params)
            ->setValue($value);
    }

    /**
     * @Given /^I fill in test CC info with following parameters:$/
     */
    public function iFillInTestCcInfo(TableNode $params)
    {
        $this->selectOptionInFiedsetWithParams('credit_card_type', 'VI', 'payment_method', $params);
        $this->selectOptionInFiedsetWithParams('expiration_month', '5', 'payment_method', $params);
        $this->selectOptionInFiedsetWithParams('expiration_year', '2018', 'payment_method', $params);
        $this->fillField('card_number', '4111111111111111', 'payment_method', null, $params);
        $this->fillField('card_verification_number', '123', 'payment_method', null, $params);
    }

    /**
     * Checks radio marked as checkbox.
     *
     * @When /^(?:|I )set "(?P<option>(?:[^"]|\\")*)" in fieldset "(?P<fieldset>(?:[^"]|\\")*)"$/
     * @When /^(?:|I )set "(?P<option>(?:[^"]|\\")*)" in fieldset "(?P<fieldset>(?:[^"]|\\")*)" of tab "(?P<tab>(?:[^"]|\\")*)"$/
     * @When /^(?:|I )set "(?P<option>(?:[^"]|\\")*)" in fieldset "(?P<fieldset>(?:[^"]|\\")*)" of tab "(?P<tab>(?:[^"]|\\")*)" with following parameters:$/
     */
    public function setOption($option, $fieldset = null, $tab = null, TableNode $params = null)
    {
        $this->checkOption($option, $fieldset, $tab, $params );
    }

    /**
     * Checks checkbox with specified id|name|label|value.
     *
     * @When /^(?:|I )set "(?P<option>(?:[^"]|\\")*)" in fieldset "(?P<fieldset>(?:[^"]|\\")*)" with following parameters:$/
     */
    public function setOptionInFiedsetWithParams($option, $fieldset, TableNode $params)
    {
        $this->setOption($option, $fieldset, null, $params);
    }

}
